from model import Inspector, OperationError


class NuevoInspector(Inspector):
    def execute(self, device_info, extracted_data_dir_path):
        pass