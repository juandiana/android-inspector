from cybox.common.object_properties import CustomProperties, Property
from cybox.objects.custom_object import Custom


class NuevoTipoDeDato(Custom):
    def __init__(self):
        Custom.__init__(self)
        self.custom_name = 'NuevoTipoDeDato'
        self.custom_properties = CustomProperties()
