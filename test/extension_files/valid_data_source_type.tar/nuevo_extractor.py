from model.operation import Extractor, OperationError

class NuevoExtractor(Extractor):
    def execute(self, extracted_data_dir_path, param_values):
        pass  