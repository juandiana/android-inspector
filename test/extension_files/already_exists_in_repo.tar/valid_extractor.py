# coding=utf-8
from model import Extractor


class ValidExtractor(Extractor):
    def execute(self, extracted_data_dir_path, param_values):
        pass
