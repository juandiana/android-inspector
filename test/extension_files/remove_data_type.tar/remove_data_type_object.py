from cybox.common.object_properties import CustomProperties, Property
from cybox.objects.custom_object import Custom


class RemoveDataType(Custom):
    def __init__(self):
        Custom.__init__(self)
        self.custom_name = 'RemoveDataType'
        self.custom_properties = CustomProperties()
