# coding=utf-8

import os
import re

from cybox.common import datetime
from cybox.common.vocabs import ObjectRelationship
from cybox.objects.email_message_object import EmailHeader, EmailMessage, Attachments

from model.operation import Inspector
from util.inspectors_helper import create_file_object, execute_query


class EmailMessageAdbBackupInspector(Inspector):
    def execute(self, device_info, extracted_data_dir_path):
        original_app_path = '/data/data/com.android.email'
        headers_db_rel_file_path = os.path.join('databases', 'EmailProvider.db')
        bodies_db_rel_file_path = os.path.join('databases', 'EmailProviderBody.db')

        original_headers_db_file_path = os.path.join(original_app_path, headers_db_rel_file_path)
        original_bodies_db_file_path = os.path.join(original_app_path, bodies_db_rel_file_path)
        headers_db_file_path = os.path.join(extracted_data_dir_path, headers_db_rel_file_path)
        bodies_db_file_path = os.path.join(extracted_data_dir_path, bodies_db_rel_file_path)

        source_objects = [
            create_file_object(headers_db_file_path, original_headers_db_file_path),
            create_file_object(bodies_db_file_path, original_bodies_db_file_path)
        ]
        inspected_objects = {}

        illegal_xml_chars_re = re.compile(u'[\x02]')
        
        cursor, conn = execute_query(headers_db_file_path, 'SELECT * FROM message')
        for row in cursor:
            header = EmailHeader()
            if row['toList']:
                header.to = illegal_xml_chars_re.sub('?', row['toList'].encode('ascii', errors='ignore'))
            if row['ccList']:
                header.cc = illegal_xml_chars_re.sub('?', row['ccList'].encode('ascii', errors='ignore'))
            if row['bccList']:
                header.bcc = illegal_xml_chars_re.sub('?', row['bccList'].encode('ascii', errors='ignore'))
            if row['fromList']:
                header.from_ = illegal_xml_chars_re.sub('?', row['fromList'].encode('ascii', errors='ignore'))
            if row['subject']:
                header.subject = illegal_xml_chars_re.sub('?', row['subject'].encode('ascii', errors='ignore'))
            if row['replyToList']:
                header.in_reply_to = illegal_xml_chars_re.sub('?', row['replyToList'].encode('ascii', errors='ignore'))
            header.date = datetime.fromtimestamp(row['timeStamp'] / 1000)  # Convert from milliseconds to seconds
            if row['messageId']:
                header.message_id = illegal_xml_chars_re.sub('?', row['messageId'].encode('ascii', errors='ignore'))

            email = EmailMessage()
            email.header = header
            email.add_related(source_objects[0], ObjectRelationship.TERM_EXTRACTED_FROM, inline=False)

            # Add the email to the inspected_objects dict using its _id value as key.
            email_id = row['_id']
            inspected_objects[email_id] = email
        cursor.close()
        conn.close()

        # Add full raw body to emails.
        cursor, conn = execute_query(bodies_db_file_path, 'SELECT _id, htmlContent, textContent FROM body')
        for row in cursor:
            email_id = row['_id']
            email = inspected_objects.get(email_id)
            if email is not None:
                if row['htmlContent'] != '':
                    email.raw_body = row['htmlContent']
                    email.header.content_type = 'text/html'
                else:
                    email.raw_body = row['textContent']
                    email.header.content_type = 'text/plain'
                email.add_related(source_objects[1], ObjectRelationship.TERM_EXTRACTED_FROM, inline=False)
        cursor.close()

        conn.close()

        return inspected_objects.values(), source_objects
